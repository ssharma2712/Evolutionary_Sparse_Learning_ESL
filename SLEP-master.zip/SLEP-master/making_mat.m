clear, clc;
pathName = 'E:\phenotype_McL\Phen_Aqua\genewise';
addpath(genpath('C:\Users\tuj44355\Downloads\SLEP-master'));
fileList = dir(fullfile(pathName, '*.csv'));
all_data_hypox = [];
for i = 1:size(fileList,1)
    s = fullfile(pathName, fileList(i).name);
    table = readtable(s,'Delimiter',',','ReadVariableNames',1);
    a= fileList(i).name;
    a= strcat(a(1:size(a,2)-4), '.mat');
    save(fullfile( 'C:\Users\tuj44355\Downloads\data_acuatic',a), 'table');
    fprintf('Executed %g th run\n',i );
end
